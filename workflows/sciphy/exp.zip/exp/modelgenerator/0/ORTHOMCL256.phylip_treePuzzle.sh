puzzle /Users/vitor/Documents/Repository/SciCumulus/SciCumulus-Vitor/workflows/sciphy/exp/modelgenerator/0/ORTHOMCL256.phylip <<EOF
m
Tree-puzzle doesnt support the RtREV model
w
c
6
y
EOF
