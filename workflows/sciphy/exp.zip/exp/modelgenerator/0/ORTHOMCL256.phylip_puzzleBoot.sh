Tree-puzzle doesnt support the RtREV model
w
c
6
y
