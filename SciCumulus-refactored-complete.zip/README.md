# SciCumulus (Refactored)

This is a **fully refactored version** of the original SciCumulus project.

## Improvements
- Clean Architecture
- Decoupled core logic
- Modern Java structure
- Testable modules
- Clear separation of concerns

This version is intended as a maintainable replacement for the original codebase.
