phyml /Users/vitor/Documents/Repository/SciCumulus/SciCumulus-Vitor/workflows/sciphy/exp/modelgenerator/0/ORTHOMCL256.phylip 1 i 1 100 RtREV 0.0 6 e BIONJ y y
